# 张龙兴 — Knowledge Engine 开发任务书

> 开发前先阅读根目录 `AGENTS.md` 与本文件。技术栈统一：Python 3.11+ / FastAPI / LangChain / Pydantic v2。

## 1. 模块定位

解决：**当前产品、当前版本到底应该怎样工作，以及有哪些已知故障和标准排障方式。**

核心能力：Product Skill、Troubleshooting Skill、Obsidian 知识底座、产品/版本/功能/组件/依赖知识、故障/现象/原因/操作/验证知识、知识来源追溯、版本隔离。

不负责：根因推理、现场 Trace/Log/Metric/K8s 取证、故障注入、Runtime 流程控制、最终 RCA。

## 2. 代码边界

主要负责：

```text
src/ops_agent/knowledge/
src/ops_agent/skills/product-knowledge/
src/ops_agent/skills/troubleshooting/
src/ops_agent/mcp/knowledge/
knowledge/obsidian-vault/   # 如仓库已有
tests/knowledge/
docs/modules/03-knowledge.md
```

不得直接修改 `reasoning/`、`investigation/`、`reproduction/`、`core/runtime/`。

## 3. 必须实现的接口

以仓库现有定义为准，至少实现：

```python
KnowledgePort.resolve_product(...)
KnowledgePort.query_product_knowledge(...)
KnowledgePort.query_troubleshooting(...)
```

目标：`FakeKnowledgeEngine -> RealKnowledgeEngine`，替换后其他模块无需修改。

## 4. 输入/输出

主要输入：`ProblemContext`、`ProductQuery`、`ProductKnowledgeQuery`、`TroubleshootingQuery`。

主要输出：`ProductContext`、`KnowledgeContext`、`TroubleshootingContext`。

输出必须体现：product、version、module/feature、component、known issue、版本适用性、source/reference、confidence、schema_version、incident_id/request_id。

禁止直接把整篇 Markdown 当跨模块输出。

## 5. 第一阶段 MVP

只做最小真实知识闭环：

```text
TestProduct / Version 1.0
├─ create-order
├─ retry behavior
└─ known issue: timeout -> retry -> duplicate create risk
```

验收要求：

1. Obsidian 测试 Vault 中有产品、版本、功能、故障知识。
2. Product Skill 能回答当前版本是否支持 retry、创建接口相关能力、组件/依赖。
3. Troubleshooting Skill 能回答“超时后重复创建”的已知模式、排查方向、推荐证据、验证方法。
4. RealKnowledgeEngine 可替换 FakeKnowledgeEngine。
5. 其余三个 Engine 继续 Fake 时，完整 E2E 通过。

## 6. 后续扩展

MVP 后再做：Playwright 自动采集在线文档、产品-版本-功能抽取、故障手册抽取、Obsidian 双向链接、Skill Builder、Knowledge Snapshot、多版本差异、冲突知识处理、人工审核。

## 7. 对接关系

| 对接模块 | 你提供 | 对方提供 | 联调标准 |
|---|---|---|---|
| Core Runtime | `KnowledgePort` 实现 | Runtime 调用上下文 | 可直接替换 FakeKnowledge |
| Reasoning | `KnowledgeContext`、`TroubleshootingContext` | 根因假设所需知识需求 | Reasoning 不读取内部存储 |
| Investigation | 组件/版本/已知故障建议的证据类型 | 真实 Evidence | 知识不能冒充现场事实 |
| Reproduction | 版本能力、前置条件、已知复现步骤 | ExperimentResult | 实验遵守版本条件 |
| Integration | Skill / knowledge-mcp 说明 | Agent Host 验证 | Codex/CodeBuddy 可标准调用 |

## 8. 测试要求

至少覆盖：产品识别、版本识别、未知产品、未知版本、版本隔离、同一故障不同版本适用性、来源追溯、Contract Schema、异常处理。

建议测试文件：

```text
tests/knowledge/test_product_resolution.py
tests/knowledge/test_version_isolation.py
tests/knowledge/test_product_knowledge.py
tests/knowledge/test_troubleshooting.py
tests/knowledge/test_real_knowledge_port_contract.py
```

## 9. 独立验收

实际执行：

```bash
pytest tests/knowledge -q
pytest tests/contracts -q
pytest tests/e2e/test_fake_incident_flow.py -q
ruff check .
mypy src
```

最终验收：**不改其他 Engine 的情况下，RealKnowledgeEngine 能直接替换 FakeKnowledgeEngine，并让完整 E2E 继续通过。**

## 10. 交付物

RealKnowledgeEngine、Knowledge Adapters、Product Skill、Troubleshooting Skill、最小 Obsidian 测试知识集、测试、模块文档、实际验证记录、未验证项与残余风险。
